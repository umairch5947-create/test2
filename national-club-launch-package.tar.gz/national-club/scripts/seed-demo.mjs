// Optional non-public draft only. Never seed real availability, rates or reservations.
const {db}=await import('../lib/db.ts');
db.prepare("INSERT OR IGNORE INTO room_types(slug,name,description,capacity,beds,amenities,inventory,rate,image,active) VALUES ('demo-room-draft','DEMO DRAFT — replace with approved room','Unpublished example. Replace details with hotel-approved information before enabling.',2,'','',0,NULL,'',0)").run();
console.log('Created an unpublished draft room with zero inventory and no rate.');
