import test from 'node:test';import assert from 'node:assert/strict';import {hotelDateTime} from '../lib/dates.ts';
test('database UTC timestamps display in Karachi local time',()=>{const formatted=hotelDateTime('2026-10-14 00:00:00');assert.match(formatted,/5:00/);assert.match(formatted,/14/)});
