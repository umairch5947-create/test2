# National Club Hotel & Restaurant

Responsive Next.js hotel website and SQLite-backed management application for Dera Ismail Khan. [Live public site](http://localhost:3000) when running locally. The address and phone come from the client; the original website supports the hotel's identity as a hotel, restaurant and event venue. No unverified room rates, inventory, guest reviews or policies are published. Owner-approved property photographs now replace the illustrative hero; the restaurant shows menu items and prices confirmed current by the owner, alongside the original menu scans.

## Quick start

Requires Node.js 20+. Run `npm install`, copy `.env.example` to `.env.local`, and provide a strong random `SESSION_SECRET` and one-time `SETUP_TOKEN`. Run `npm run dev` and visit `http://localhost:3000`. The app automatically initializes/migrates its SQLite schema in `hotel.db`, or the persistent path defined by `DB_PATH`. Visit `/admin/setup` with the setup token to create the first owner; remove `SETUP_TOKEN` from configuration afterwards. Log in at `/admin/login`. **No default admin credentials exist.**

The site is configured for **enquiry-only operation**: visitors can send a room request without a published room category. A private, non-published system category stores these requests; no rate or availability is claimed. Optional: `npm run seed:demo` adds an **unpublished** draft room with zero inventory and no rate. It never creates fake bookings. To publish actual room choices later, add approved room types and inventory in the admin dashboard. Enter rates in PKR; the database stores minor units.

## Features

- Home, about, rooms, room detail, booking request, restaurant, facilities, events, gallery, contact and editable legal pages.
- Server-validated booking requests, unique references, duplicate submission protection, per-night availability checks, maintenance blocks and seasonal rates. Booking requests are **Pending** until hotel staff confirm; confirming checks physical inventory again within a SQLite write transaction. If inventory is unconfigured, staff must verify it manually before confirming. No payment is collected.
- Contact, dining and event inquiries stored in SQLite. Booking status transitions, internal notes, audit entries, searchable/paginated booking list, CSV export, and dashboard figures based on stored records.
- Owner/staff accounts, bcrypt password hashing, signed HttpOnly session cookies, same-origin mutation checks and SQLite-backed request throttling.
- Admin can edit phone, address, maps link, verified email, booking rules, optional taxes/fees and the approved hero image from Settings; add/edit rooms; add/edit/delete menu items, gallery entries, facilities, FAQs and verified reviews; add/delete seasonal rates and maintenance blocks; update public copy and publish approved policies. Menu, facility, FAQ and review items can be hidden; new reviews are unpublished by default and require a source URL. Staff can upload JPEG, PNG or WebP images (up to 5 MB) for rooms, menu items and gallery entries; uploads are decoded, stripped of metadata, resized to a maximum of 1800 pixels and re-encoded as WebP before storage in `MEDIA_DIR` and served by a controlled media route. Approved HTTPS URLs are also supported.
- Directions, click-to-call and user-initiated WhatsApp inquiry links. No automatic WhatsApp message is sent.

## Verification

Run `npm test` for SQLite schema and integration checks of availability, maintenance, seasonal pricing, configured taxes/fees, date rules, timestamps and upload validation. Run `npm run build` to verify the production build. Neither command substitutes for full browser/e2e testing. An isolated production-mode API smoke test also passed; its temporary database and uploads were removed afterwards.

## Production deployment with SQLite

Deploy as **one persistent Node.js instance** on a VPS or other host with durable writable storage; do **not** use ephemeral serverless filesystems or multiple independent database files. Set `DB_PATH` to an absolute path on persistent storage outside the deployed code tree, `SESSION_SECRET` to a long random secret, `MEDIA_DIR` to a persistent directory and `NEXT_PUBLIC_SITE_URL` to the real canonical domain. Put the app behind HTTPS, run `npm ci && npm run build && npm run start`, restrict file permissions, and back up both `MEDIA_DIR` and the SQLite database plus WAL safely (SQLite backup API or `.backup`, not just copying an active database file). Monitor disk capacity, errors and backups. Keep dependencies updated. An initial schema snapshot is provided at `migrations/001_initial.sql`; the runtime initializes tables and applies additive column updates in `lib/db.ts`. For future destructive schema changes, use a reviewed versioned migration process. `npm run backup -- /absolute/path/backup.sqlite` uses the SQLite backup API; back up `MEDIA_DIR` separately.

## Before public launch

For an enquiry-only publication, privacy/legal review, hosting and domain setup, and a staff handover are still necessary. Owner-approved photos and current menu pricing are included. Room categories, inventory, room rates and operating hours remain unpublished until verified. SMS notifications, password reset, richer permissions, analytics consent and full browser/e2e test coverage remain integration work. Notifications are **not** claimed as delivered. Tax percentage and a one-time per-request fee can be configured in Admin → Settings; leave them blank unless approved by the hotel. Estimates exclude unconfigured charges. No real reviews are published until sourced and enabled by staff. Optional SMTP email notifications are configured through `SMTP_URL`, `FROM_EMAIL` and `HOTEL_NOTIFICATION_EMAIL`. Email errors are logged under Admin → Notifications and never roll back a saved booking; “accepted” means the provider accepted the message, not confirmed delivery.

Original public reference: https://www.nationalclubpk.com/ · Supplied directions: https://maps.app.goo.gl/H64eascF4vSGw4Yv9?g_st=ac

## Isolated end-to-end smoke test

`scripts/smoke-e2e.mjs` tests setup, login, admin authorization, room creation, invalid and valid bookings, duplicate rejection, confirmation, inventory conflict, safe photo upload, gallery, review drafts, guest data anonymization, staff role revocation and contact inquiry deletion against a **separate temporary database**. It was executed successfully against a temporary production-mode server; never aim it at the live hotel database. Create an isolated `DB_PATH`, set test-only `SESSION_SECRET`/`SETUP_TOKEN`, run the built app on port 3100 and then execute `DB_PATH=... SETUP_TOKEN=... node scripts/smoke-e2e.mjs`. Remove the temporary database afterwards.

## Data retention and security notes

Authorized staff can delete inquiries and anonymize **closed** bookings; both actions are audit-logged. Decide a lawful retention schedule with the hotel before launch and perform periodic reviews. Backups also contain personal data and need restricted access and a retention schedule. The site does not collect payment details or government IDs. The `MEDIA_DIR` must be writable by the application but not directly executable by the web server. Configure a reverse proxy with TLS and security monitoring; if running behind one, review trusted forwarding headers and IP-based throttling.

## Owner-approved photo and menu content

The owner supplied and authorized 12 property photographs and three menu images, and confirmed the attached menu prices current and approved. Cropped property photos and optimized menu scans are in `public/photos/`. `lib/approved-content.ts` seeds the photo gallery and 48 clearly transcribed menu items on first database initialization. Staff can edit/hide them in Admin → Gallery and Admin → Restaurant. The original scans are linked from the restaurant page for the complete menu. No room rate or policy has been inferred from these assets.
