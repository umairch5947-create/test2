// Source: hotel-approved photos and current menu images supplied by the business owner in this conversation.
// Room categories, inventory, policies and operating hours were not supplied and are not seeded.
export const approvedGallery=[
 {url:'/photos/garden-evening.webp',alt:'National Club building and landscaped garden in evening light',category:'Gardens'},
 {url:'/photos/entrance.webp',alt:'Entrance gate and National Club sign',category:'Exterior'},
 {url:'/photos/guest-room.webp',alt:'Guest room bed with upholstered headboard and bedside lamps',category:'Rooms'},
 {url:'/photos/garden-lawn.webp',alt:'Landscaped lawn and palm trees at National Club',category:'Gardens'},
 {url:'/photos/restaurant-dining.webp',alt:'Dining tables set inside National Club',category:'Restaurant'},
 {url:'/photos/event-hall.webp',alt:'National Club hall arranged with tables for a gathering',category:'Events'},
 {url:'/photos/banquet-setup.webp',alt:'Banquet seating and buffet setup at National Club',category:'Events'},
 {url:'/photos/sitting-area.webp',alt:'Guest sitting area with sofas at National Club',category:'Rooms'},
 {url:'/photos/garden-path.webp',alt:'Garden path lined with palms and plants at National Club',category:'Gardens'},
 {url:'/photos/outdoor-courtyard.webp',alt:'Covered outdoor gathering area at National Club',category:'Outdoor'},
 {url:'/photos/corridor.webp',alt:'Interior passage with windows at National Club',category:'Property'},
 {url:'/photos/guest-bathroom.webp',alt:'Guest bathroom at National Club',category:'Rooms'}
];
// Prices in PKR transcribed from user-provided menu images, confirmed current and approved by owner.
// Only unambiguous single-price items are transcribed here; full menu images appear on restaurant page.
export const approvedMenu:[string,string,number][]= [
 ['Burgers & Sandwiches','National Club Special Burger',320],['Burgers & Sandwiches','Chicken Burger with French Fries',250],['Burgers & Sandwiches','Chicken Cheese Burger with French Fries',290],['Burgers & Sandwiches','Beef Burger',200],['Burgers & Sandwiches','Chicken Sandwich',210],['Burgers & Sandwiches','Club Sandwich',250],['Burgers & Sandwiches','Chicken Cheese Sandwich',240],['Burgers & Sandwiches','Chips (Plate)',120],
 ['Chinese Rice','National Club Special Rice',450],['Chinese Rice','Chicken Fried Rice',420],['Chinese Rice','Chicken Masala Rice',420],['Chinese Rice','Egg Fried Rice',390],['Chinese Rice','Vegetable Rice',390],['Chinese Rice','Beef Chilli Rice',430],['Chinese Rice','Plain Rice',210],['Chinese Rice','Chicken Biryani',380],['Chinese Rice','Mutton Biryani',520],
 ['Chowmein','National Club Chicken Chowmein',550],['Chowmein','Chicken Chowmein',500],['Chowmein','Beef Chowmein',490],['Chowmein','Vegetable Chowmein',400],
 ['Soups','National Club Special Soup — Full',550],['Soups','National Club Special Soup — Half',300],['Soups','Hot & Sour Soup — Full',450],['Soups','Hot & Sour Soup — Half',250],['Soups','Chicken Corn Soup — Full',400],['Soups','Chicken Corn Soup — Half',220],
 ['Tandoor','Roghni Naan',40],['Tandoor','Ginger Naan',70],['Tandoor','Garlic Naan',70],['Tandoor','Cheese Naan',90],['Tandoor','Chicken Naan',120],['Tandoor','Sada Naan',30],['Tandoor','Tandoori Roti (per head)',40],
 ['Drinks','Milk Tea (Mix)',50],['Drinks','Green Tea',35],['Drinks','Cappuccino Coffee',120],['Drinks','Soft Drink',40],['Drinks','Mineral Water (Large)',70],['Drinks','Mineral Water (Small)',50],['Drinks','Fresh Lime',60],
 ['Salads','Kachoomer Salad',120],['Salads','Fresh Green Salad',70],['Salads','Raita',70],
 ['Bar B-Q','Chicken Tikka (per piece)',160],['Bar B-Q','Chicken Tikka Boti (4 pieces)',430],['Bar B-Q','Chicken Malai Boti (4 pieces)',550],['Bar B-Q','Chicken Kabab (6 pieces)',430]
];
export const approvedMenuImages=['/photos/menu4.webp','/photos/menu3.webp','/photos/menu2.webp'];
