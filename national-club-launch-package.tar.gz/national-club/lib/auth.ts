import {cookies} from 'next/headers';import crypto from 'crypto';import {db} from './db';
const secret=process.env.SESSION_SECRET||(process.env.NODE_ENV==='production'?'':'development-only-change-this-secret');
export function sign(email:string){if(!secret)throw new Error('SESSION_SECRET is required in production');const exp=Date.now()+86400000;const value=`${email}|${exp}`;return Buffer.from(value).toString('base64url')+'.'+crypto.createHmac('sha256',secret).update(value).digest('hex')}
export async function admin(){if(!secret)return null;const raw=(await cookies()).get('nc_session')?.value;if(!raw)return null;const [b,sig]=raw.split('.');if(!b||!sig)return null;const value=Buffer.from(b,'base64url').toString();const expected=crypto.createHmac('sha256',secret).update(value).digest('hex');if(sig.length!==expected.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return null;const [email,exp]=value.split('|');return Number(exp)>Date.now()?email:null}

export async function staff(){const email=await admin();if(!email)return null;return db.prepare('SELECT id,email,role FROM users WHERE email=?').get(email) as {id:number;email:string;role:string}|undefined}
