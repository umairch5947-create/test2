import path from 'path';
export const mediaDir=path.resolve(process.env.MEDIA_DIR||path.join(process.cwd(),'media'));
export const safeMediaUrl=(url:unknown)=>typeof url==='string'&&(/^(https:\/\/[^\s]{1,1000})$/.test(url)||/^\/api\/media\/[a-f0-9]{32}\.(jpg|png|webp)$/.test(url)||/^\/photos\/[a-z0-9-]+\.webp$/.test(url));
export function imageKind(bytes:Buffer){if(bytes.length>=3&&bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)return {ext:'jpg',mime:'image/jpeg'};if(bytes.length>=8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return {ext:'png',mime:'image/png'};if(bytes.length>=12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')return {ext:'webp',mime:'image/webp'};return null}
