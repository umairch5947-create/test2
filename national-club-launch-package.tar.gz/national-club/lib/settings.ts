import {db} from './db';
const defaults={phone:'+923005799194',address:'River Indus Road, Near Mehmood Eye Hospital, Dera Ismail Khan, Khyber Pakhtunkhwa, Pakistan',maps:'https://maps.app.goo.gl/H64eascF4vSGw4Yv9?g_st=ac',email:'',taxPercent:'',feePkr:'',minLeadDays:'0',maxNights:'90',heroImage:'/photos/garden-evening.webp'};
export type Settings=typeof defaults;
export function settings():Settings{const out={...defaults};for(const row of db.prepare('SELECT key,value FROM site_settings').all() as {key:keyof Settings;value:string}[]){if(Object.hasOwn(out,row.key))out[row.key]=row.value}return out}
export function displayPhone(number:string){return number==='+923005799194'?'+92 300 5799194':number}
export function whatsapp(number:string){return 'https://wa.me/'+number.replace(/\D/g,'')}
