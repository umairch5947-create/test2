# Enquiry-only launch checklist

This site accepts room **requests**, not guaranteed reservations. It works with zero published room categories, inventory or rates. Staff must reply and verify each request manually.

## Required from hotel before public publication

- [x] Owner-approved property photographs supplied and integrated; phone-screen UI cropped. Hero and gallery use authentic photos.
- [ ] Confirm owner-approved privacy notice and legal review for storing names, phone numbers and booking dates. Current policy pages explicitly say they have not been published; they are not approved legal policies.
- [ ] Review business address, phone and Maps directions. Enter a verified email only if one exists.
- [ ] Assign staff to monitor Admin → Bookings and Admin → Inquiries; establish response times and phone confirmation procedure.
- [x] Restaurant menu items and prices approved by owner and published with original menu scans.
- [ ] Keep room categories, room rates, operating hours, unverified facilities and reviews unpublished until individually verified.

## Required to place it online

- [ ] Obtain a single persistent Node.js host/VPS with a writable SQLite and media directory, DNS access to the chosen domain and HTTPS/TLS.
- [ ] Set environment variables from `.env.example` (`SESSION_SECRET`, `DB_PATH`, `MEDIA_DIR`, `NEXT_PUBLIC_SITE_URL`, one-time `SETUP_TOKEN`). Keep secrets server-side; remove setup token after the first owner is created.
- [ ] Run `npm ci && npm run build && npm run start`, create the owner via `/admin/setup`, and test a real enquiry from a phone. Configure SMTP only if email notifications are wanted; never assume email delivery.
- [ ] Set automated SQLite backups with `npm run backup -- /absolute/path/backup.sqlite`, back up media files separately, and test restoring both.
- [ ] Test on actual mobile, tablet and desktop browsers. Verify the map pin, tap-to-call and WhatsApp links.
- [ ] Update DNS after the above checks pass. The preview is not a deployed public website.
